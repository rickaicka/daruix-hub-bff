from django.apps import AppConfig


class CommercialConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "commercial"
    verbose_name = "Comercial"
