﻿from django.db.models import Prefetch
from django.http import FileResponse, Http404
from django_filters.rest_framework import DjangoFilterBackend
from drf_spectacular.types import OpenApiTypes
from drf_spectacular.utils import (
    OpenApiResponse,
    extend_schema,
    extend_schema_view,
)
from rest_framework import status
from rest_framework.decorators import action
from rest_framework.filters import (
    OrderingFilter,
    SearchFilter,
)
from rest_framework.parsers import (
    FormParser,
    MultiPartParser,
)
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.viewsets import ModelViewSet

from memorando_remessas.filters import ShipmentMemoFilter
from memorando_remessas.models import (
    ShipmentMemo,
    ShipmentMemoFile,
    ShipmentMemoOption,
    ShipmentMemoResponsible,
)
from memorando_remessas.pagination import (
    ShipmentMemoPagination,
)
from memorando_remessas.permissions import (
    HasShipmentMemoCancelPermission,
    HasShipmentMemoCreatePermission,
    HasShipmentMemoDeletePermission,
    HasShipmentMemoSendPermission,
    HasShipmentMemoUpdatePermission,
    HasShipmentMemoViewPermission,
)
from memorando_remessas.serializers import (
    ShipmentMemoCancelSerializer,
    ShipmentMemoFileSerializer,
    ShipmentMemoFileUploadSerializer,
    ShipmentMemoHistorySerializer,
    ShipmentMemoListSerializer,
    ShipmentMemoRevisionSerializer,
    ShipmentMemoSendSerializer,
    ShipmentMemoSerializer,
)
from memorando_remessas.services import (
    add_shipment_memo_file,
    cancel_shipment_memo,
    create_shipment_memo_revision,
    delete_shipment_memo,
    delete_shipment_memo_file,
    send_shipment_memo,
)


@extend_schema_view(
    list=extend_schema(
        tags=["memorando-remessas/memorandos"],
        summary="Listar memorandos de remessa",
    ),
    retrieve=extend_schema(
        tags=["memorando-remessas/memorandos"],
        summary="Detalhar memorando de remessa",
    ),
    create=extend_schema(
        tags=["memorando-remessas/memorandos"],
        summary="Criar memorando de remessa",
    ),
    update=extend_schema(
        tags=["memorando-remessas/memorandos"],
        summary="Atualizar memorando de remessa",
    ),
    partial_update=extend_schema(
        tags=["memorando-remessas/memorandos"],
        summary="Atualizar parcialmente memorando",
    ),
    destroy=extend_schema(
        tags=["memorando-remessas/memorandos"],
        summary="Excluir memorando em rascunho",
    ),
)
class ShipmentMemoViewSet(ModelViewSet):
    serializer_class = ShipmentMemoSerializer
    pagination_class = ShipmentMemoPagination

    filter_backends = [
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    ]

    filterset_class = ShipmentMemoFilter

    search_fields = [
        "code",
        "cost_center",
        "work_name",
        "client_name",
        "client_document",
        "subject",
        "attention_to",
        "responsible_links__user__name",
        "responsible_links__user__username",
        "responsible_links__user__email",
    ]

    ordering_fields = [
        "id",
        "code",
        "revision",
        "status",
        "shipping_date",
        "work_name",
        "client_name",
        "cost_center",
        "created_at",
        "updated_at",
    ]

    ordering = [
        "-created_at",
    ]

    def get_queryset(self):
        responsible_queryset = (
            ShipmentMemoResponsible.objects
            .select_related(
                "user",
                "added_by",
            )
            .order_by(
                "-is_primary",
                "created_at",
                "id",
            )
        )

        option_queryset = (
            ShipmentMemoOption.objects
            .order_by(
                "option_type",
                "order",
                "name",
                "id",
            )
        )

        file_queryset = (
            ShipmentMemoFile.objects
            .select_related(
                "uploaded_by",
            )
            .order_by(
                "-created_at",
                "-id",
            )
        )

        return (
            ShipmentMemo.objects
            .select_related(
                "revised_from",
                "created_by",
                "updated_by",
                "sent_by",
                "cancelled_by",
            )
            .prefetch_related(
                Prefetch(
                    "responsible_links",
                    queryset=responsible_queryset,
                ),
                Prefetch(
                    "options",
                    queryset=option_queryset,
                ),
                Prefetch(
                    "files",
                    queryset=file_queryset,
                ),
            )
            .all()
            .distinct()
        )

    def get_serializer_class(self):
        if self.action == "list":
            return ShipmentMemoListSerializer

        if self.action == "send_memo":
            return ShipmentMemoSendSerializer

        if self.action == "cancel_memo":
            return ShipmentMemoCancelSerializer

        if self.action == "create_revision":
            return ShipmentMemoRevisionSerializer

        if self.action == "history":
            return ShipmentMemoHistorySerializer

        if self.action == "files":
            if self.request.method == "POST":
                return ShipmentMemoFileUploadSerializer

            return ShipmentMemoFileSerializer

        if self.action in [
            "delete_file",
            "download_file",
        ]:
            return ShipmentMemoFileSerializer

        return ShipmentMemoSerializer

    def get_permissions(self):
        permission_classes = [
            IsAuthenticated,
        ]

        if self.action in [
            "list",
            "retrieve",
            "history",
            "download_file",
        ]:
            permission_classes.append(
                HasShipmentMemoViewPermission
            )

        elif self.action == "create":
            permission_classes.append(
                HasShipmentMemoCreatePermission
            )

        elif self.action in [
            "update",
            "partial_update",
        ]:
            permission_classes.append(
                HasShipmentMemoUpdatePermission
            )

        elif self.action == "destroy":
            permission_classes.append(
                HasShipmentMemoDeletePermission
            )

        elif self.action == "send_memo":
            permission_classes.append(
                HasShipmentMemoSendPermission
            )

        elif self.action == "cancel_memo":
            permission_classes.append(
                HasShipmentMemoCancelPermission
            )

        elif self.action == "create_revision":
            permission_classes.extend([
                HasShipmentMemoViewPermission,
                HasShipmentMemoCreatePermission,
            ])

        elif self.action == "files":
            if self.request.method == "POST":
                permission_classes.append(
                    HasShipmentMemoUpdatePermission
                )
            else:
                permission_classes.append(
                    HasShipmentMemoViewPermission
                )

        elif self.action == "delete_file":
            permission_classes.append(
                HasShipmentMemoUpdatePermission
            )

        return [
            permission_class()
            for permission_class in permission_classes
        ]

    def perform_destroy(self, instance):
        delete_shipment_memo(
            shipment_memo=instance,
        )

    def _serialize_detail(
        self,
        shipment_memo: ShipmentMemo,
    ) -> dict:
        instance = (
            self.get_queryset()
            .get(pk=shipment_memo.pk)
        )

        serializer = ShipmentMemoSerializer(
            instance,
            context=self.get_serializer_context(),
        )

        return serializer.data

    @extend_schema(
        tags=["memorando-remessas/memorandos"],
        summary="Enviar memorando de remessa",
        description=(
            "Valida o memorando, altera o status para "
            "PROCESSANDO_ENVIO e envia um e-mail com o PDF "
            "do memorando e os arquivos anexados. Em caso de "
            "sucesso, altera o status para ENVIADO. Em caso de "
            "erro, altera para FALHA_ENVIO."
        ),
        request=ShipmentMemoSendSerializer,
        responses={
            200: ShipmentMemoSerializer,
        },
    )
    @action(
        detail=True,
        methods=["post"],
        url_path="enviar",
        url_name="enviar",
    )
    def send_memo(
        self,
        request,
        pk=None,
    ):
        shipment_memo = self.get_object()

        input_serializer = ShipmentMemoSendSerializer(
            data=request.data,
            context=self.get_serializer_context(),
        )

        input_serializer.is_valid(
            raise_exception=True,
        )

        shipment_memo = send_shipment_memo(
            shipment_memo=shipment_memo,
            user=request.user,
        )

        return Response(
            self._serialize_detail(
                shipment_memo
            ),
            status=status.HTTP_200_OK,
        )

    @extend_schema(
        tags=["memorando-remessas/memorandos"],
        summary="Cancelar memorando de remessa",
        description=(
            "Cancela um memorando que jÃ¡ foi enviado. "
            "O motivo do cancelamento Ã© obrigatÃ³rio."
        ),
        request=ShipmentMemoCancelSerializer,
        responses={
            200: ShipmentMemoSerializer,
        },
    )
    @action(
        detail=True,
        methods=["post"],
        url_path="cancelar",
        url_name="cancelar",
    )
    def cancel_memo(
        self,
        request,
        pk=None,
    ):
        shipment_memo = self.get_object()

        input_serializer = ShipmentMemoCancelSerializer(
            data=request.data,
            context=self.get_serializer_context(),
        )

        input_serializer.is_valid(
            raise_exception=True,
        )

        shipment_memo = cancel_shipment_memo(
            shipment_memo=shipment_memo,
            user=request.user,
            reason=(
                input_serializer
                .validated_data["reason"]
            ),
        )

        return Response(
            self._serialize_detail(
                shipment_memo
            ),
            status=status.HTTP_200_OK,
        )

    @extend_schema(
        tags=["memorando-remessas/memorandos"],
        summary="Criar nova revisÃ£o",
        description=(
            "Cria uma nova revisÃ£o em RASCUNHO a partir "
            "da revisÃ£o mais recente de um memorando enviado "
            "ou cancelado."
        ),
        request=ShipmentMemoRevisionSerializer,
        responses={
            201: ShipmentMemoSerializer,
        },
    )
    @action(
        detail=True,
        methods=["post"],
        url_path="nova-revisao",
        url_name="nova-revisao",
    )
    def create_revision(
        self,
        request,
        pk=None,
    ):
        shipment_memo = self.get_object()

        input_serializer = ShipmentMemoRevisionSerializer(
            data=request.data,
            context=self.get_serializer_context(),
        )

        input_serializer.is_valid(
            raise_exception=True,
        )

        new_revision = create_shipment_memo_revision(
            shipment_memo=shipment_memo,
            user=request.user,
        )

        return Response(
            self._serialize_detail(
                new_revision
            ),
            status=status.HTTP_201_CREATED,
        )

    @extend_schema(
        tags=["memorando-remessas/memorandos"],
        summary="Listar histÃ³rico do memorando",
        description=(
            "Retorna as aÃ§Ãµes realizadas no memorando, "
            "incluindo criaÃ§Ã£o, alteraÃ§Ã£o, envio, cancelamento, "
            "revisÃµes e movimentaÃ§Ãµes de arquivos."
        ),
        responses={
            200: ShipmentMemoHistorySerializer(
                many=True,
            ),
        },
    )
    @action(
        detail=True,
        methods=["get"],
        url_path="historico",
        url_name="historico",
    )
    def history(
        self,
        request,
        pk=None,
    ):
        shipment_memo = self.get_object()

        history_entries = (
            shipment_memo.history_entries
            .select_related(
                "actor",
            )
            .order_by(
                "-created_at",
                "-id",
            )
        )

        serializer = ShipmentMemoHistorySerializer(
            history_entries,
            many=True,
            context=self.get_serializer_context(),
        )

        return Response(
            serializer.data,
            status=status.HTTP_200_OK,
        )

    @extend_schema(
        methods=["GET"],
        tags=["memorando-remessas/memorandos"],
        summary="Listar arquivos do memorando",
        description=(
            "Lista os arquivos anexados ao memorando."
        ),
        responses={
            200: ShipmentMemoFileSerializer(
                many=True,
            ),
        },
    )
    @extend_schema(
        methods=["POST"],
        tags=["memorando-remessas/memorandos"],
        summary="Adicionar arquivo ao memorando",
        description=(
            "Adiciona um arquivo a um memorando em RASCUNHO. "
            "A requisiÃ§Ã£o deve usar multipart/form-data."
        ),
        request=ShipmentMemoFileUploadSerializer,
        responses={
            201: ShipmentMemoFileSerializer,
        },
    )
    @action(
        detail=True,
        methods=[
            "get",
            "post",
        ],
        url_path="arquivos",
        url_name="arquivos",
        parser_classes=[
            MultiPartParser,
            FormParser,
        ],
    )
    def files(
        self,
        request,
        pk=None,
    ):
        shipment_memo = self.get_object()

        if request.method == "GET":
            files = (
                shipment_memo.files
                .select_related(
                    "uploaded_by",
                )
                .order_by(
                    "-created_at",
                    "-id",
                )
            )

            serializer = ShipmentMemoFileSerializer(
                files,
                many=True,
                context=self.get_serializer_context(),
            )

            return Response(
                serializer.data,
                status=status.HTTP_200_OK,
            )

        input_serializer = ShipmentMemoFileUploadSerializer(
            data=request.data,
            context=self.get_serializer_context(),
        )

        input_serializer.is_valid(
            raise_exception=True,
        )

        shipment_file = add_shipment_memo_file(
            shipment_memo=shipment_memo,
            uploaded_file=(
                input_serializer
                .validated_data["file"]
            ),
            user=request.user,
        )

        serializer = ShipmentMemoFileSerializer(
            shipment_file,
            context=self.get_serializer_context(),
        )

        return Response(
            serializer.data,
            status=status.HTTP_201_CREATED,
        )

    @extend_schema(
        tags=["memorando-remessas/memorandos"],
        summary="Remover arquivo do memorando",
        description=(
            "Remove um arquivo de um memorando em RASCUNHO."
        ),
        responses={
            204: OpenApiResponse(
                description="Arquivo removido.",
            ),
            404: OpenApiResponse(
                description="Arquivo nÃ£o encontrado.",
            ),
        },
    )
    @action(
        detail=True,
        methods=["delete"],
        url_path=(
            r"arquivos/"
            r"(?P<file_id>\d+)"
        ),
        url_name="delete-file",
    )
    def delete_file(
        self,
        request,
        pk=None,
        file_id=None,
    ):
        shipment_memo = self.get_object()

        shipment_file = (
            shipment_memo.files
            .filter(
                pk=file_id,
            )
            .first()
        )

        if not shipment_file:
            raise Http404(
                "Arquivo nÃ£o encontrado."
            )

        delete_shipment_memo_file(
            shipment_memo=shipment_memo,
            shipment_file=shipment_file,
            user=request.user,
        )

        return Response(
            status=status.HTTP_204_NO_CONTENT,
        )

    @extend_schema(
        tags=["memorando-remessas/memorandos"],
        summary="Baixar arquivo do memorando",
        description=(
            "Baixa um arquivo anexado ao memorando."
        ),
        responses={
            200: OpenApiResponse(
                response=OpenApiTypes.BINARY,
                description="ConteÃºdo binÃ¡rio do arquivo.",
            ),
            404: OpenApiResponse(
                description="Arquivo nÃ£o encontrado.",
            ),
        },
    )
    @action(
        detail=True,
        methods=["get"],
        url_path=(
            r"arquivos/"
            r"(?P<file_id>\d+)/"
            r"download"
        ),
        url_name="download-file",
    )
    def download_file(
        self,
        request,
        pk=None,
        file_id=None,
    ):
        shipment_memo = self.get_object()

        shipment_file = (
            shipment_memo.files
            .filter(
                pk=file_id,
            )
            .first()
        )

        if not shipment_file:
            raise Http404(
                "Arquivo nÃ£o encontrado."
            )

        if not shipment_file.file:
            raise Http404(
                "Arquivo fÃ­sico nÃ£o encontrado."
            )

        storage = shipment_file.file.storage
        stored_file_name = shipment_file.file.name

        if not stored_file_name:
            raise Http404(
                "Arquivo fÃ­sico nÃ£o encontrado."
            )

        if not storage.exists(
            stored_file_name
        ):
            raise Http404(
                "Arquivo fÃ­sico nÃ£o encontrado."
            )

        try:
            file_handle = storage.open(
                stored_file_name,
                mode="rb",
            )
        except OSError as error:
            raise Http404(
                "NÃ£o foi possÃ­vel abrir o arquivo."
            ) from error

        return FileResponse(
            file_handle,
            as_attachment=True,
            filename=shipment_file.original_name,
            content_type=(
                shipment_file.content_type
                or "application/octet-stream"
            ),
        )


