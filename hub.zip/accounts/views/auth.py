﻿from django.contrib.auth import authenticate, get_user_model
from drf_spectacular.utils import (
    OpenApiExample,
    OpenApiResponse,
    extend_schema,
)
from rest_framework import status
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.exceptions import TokenError
from rest_framework_simplejwt.tokens import RefreshToken
from accounts.services.auth_payload_service import build_login_user_payload
from accounts.legacy.legacy_auth_client import LegacyAuthClient, LegacyAuthError
from accounts.serializers.auth import (
    LoginResponseSerializer,
    LoginSerializer,
    LogoutResponseSerializer,
    LogoutSerializer,
    MeResponseSerializer,
    RefreshResponseSerializer,
    RefreshSerializer,
)
from accounts.services.auth_payload_service import build_authenticated_user_payload
from accounts.services.legacy_import_service import LegacyImportService
from accounts.models import UserSession
from accounts.services.session_service import (
    build_access_from_refresh_token,
    build_tokens_for_session,
    close_user_session,
    create_user_session,
)

User = get_user_model()


def authenticate_django_user(request, username: str, password: str):
    return authenticate(
        request=request,
        username=username,
        password=password,
    )


class LoginView(APIView):
    permission_classes = [AllowAny]

    @extend_schema(
        tags=["auth"],
        summary="Login",
        description=(
            "Authenticates a SGOWEB user by username and password. "
            "First tries the Django database. If authentication fails, "
            "it can try the legacy Access authentication bridge."
        ),
        request=LoginSerializer,
        responses={
            200: LoginResponseSerializer,
            401: OpenApiResponse(description="Invalid username or password."),
            403: OpenApiResponse(description="User is inactive."),
            503: OpenApiResponse(description="Legacy authentication unavailable."),
        },
        examples=[
            OpenApiExample(
                name="Login request",
                value={
                    "username": "ricardo",
                    "password": "123456",
                },
                request_only=True,
            ),
            OpenApiExample(
                name="Successful login",
                value={
                    "access_token": "jwt-access-token",
                    "refresh_token": "jwt-refresh-token",
                    "token_type": "bearer",
                    "usuario": {
                        "id_usuario": 1,
                        "username": "ricardo",
                        "nome": "Ricardo Salim Daruix",
                        "email": "ricardo@daruix.com.br",
                        "tipo_usuario": "COLABORADOR",
                        "grupo": "DIRETORIA",
                        "permissoes": [
                            "proposal.view",
                            "purchase_order.approve",
                        ],
                    },
                },
                response_only=True,
            ),
        ],
    )
    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        username = serializer.validated_data["username"]
        password = serializer.validated_data["password"]

        user = authenticate_django_user(
            request=request,
            username=username,
            password=password,
        )

        if not user:
            try:
                user = self._try_legacy_login(username, password)
            except LegacyAuthError as error:
                return Response(
                    {"detail": str(error)},
                    status=status.HTTP_503_SERVICE_UNAVAILABLE,
                )

        if not user:
            return Response(
                {"detail": "Invalid username or password."},
                status=status.HTTP_401_UNAUTHORIZED,
            )

        if not user.is_active:
            return Response(
                {"detail": "User is inactive."},
                status=status.HTTP_403_FORBIDDEN,
            )

        user_payload = build_login_user_payload(user)

        session = create_user_session(user)
        tokens = build_tokens_for_session(user, session)

        return Response(
            {
                **tokens,
                "usuario": user_payload,
            },
            status=status.HTTP_200_OK,
        )

    def _try_legacy_login(self, username: str, password: str):
        legacy_client = LegacyAuthClient()
        legacy_payload = legacy_client.authenticate(username, password)

        print("LEGACY PAYLOAD:", legacy_payload)

        if not legacy_payload:
            return None

        import_service = LegacyImportService()

        return import_service.import_user_from_legacy_payload(
            payload=legacy_payload,
            raw_password=password,
        )


class MeView(APIView):
    permission_classes = [IsAuthenticated]

    @extend_schema(
        tags=["auth"],
        summary="UsuÃ¡rio autenticado",
        description="Retorna os dados completos do usuÃ¡rio autenticado, incluindo grupo e permissÃµes quando existirem.",
        responses={
            200: MeResponseSerializer,
            401: OpenApiResponse(description="Credenciais de autenticaÃ§Ã£o nÃ£o foram informadas."),
        },
    )
    def get(self, request):
        return Response(
            build_authenticated_user_payload(request.user),
            status=status.HTTP_200_OK,
        )


class LogoutView(APIView):
    permission_classes = [IsAuthenticated]

    @extend_schema(
        tags=["auth"],
        summary="Logout",
        description="Blacklists the provided refresh token.",
        request=LogoutSerializer,
        responses={
            200: LogoutResponseSerializer,
            400: OpenApiResponse(description="Invalid or expired refresh token."),
        },
        examples=[
            OpenApiExample(
                name="Logout request",
                value={
                    "refresh_token": "jwt-refresh-token",
                },
                request_only=True,
            ),
            OpenApiExample(
                name="Logout response",
                value={
                    "detail": "Logout completed successfully.",
                },
                response_only=True,
            ),
        ],
    )
    def post(self, request):
        serializer = LogoutSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        refresh_token = serializer.validated_data["refresh_token"]

        session_id = None

        if request.auth:
            session_id = request.auth.get("sid")

        try:
            token = RefreshToken(refresh_token)

            if not session_id:
                session_id = token.get("sid")

            token.blacklist()

        except TokenError:
            if session_id:
                close_user_session(
                    user=request.user,
                    session_id=session_id,
                    reason=UserSession.EndReason.LOGOUT,
                )

            return Response(
                {
                    "detail": "SessÃ£o encerrada, mas o refresh token jÃ¡ estava invÃ¡lido ou expirado."
                },
                status=status.HTTP_200_OK,
            )

        close_user_session(
            user=request.user,
            session_id=session_id,
            reason=UserSession.EndReason.LOGOUT,
        )

        return Response(
            {"detail": "Logout completed successfully."},
            status=status.HTTP_200_OK,
        )

class RefreshView(APIView):
    permission_classes = [AllowAny]

    @extend_schema(
        tags=["auth"],
        summary="Refresh token",
        description="Gera um novo access token validando a sessÃ£o ativa do usuÃ¡rio.",
        request=RefreshSerializer,
        responses={
            200: RefreshResponseSerializer,
            401: OpenApiResponse(description="Refresh token invÃ¡lido, expirado ou sessÃ£o encerrada."),
        },
    )
    def post(self, request):
        serializer = RefreshSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        refresh_token = serializer.validated_data["refresh_token"]

        return Response(
            build_access_from_refresh_token(refresh_token),
            status=status.HTTP_200_OK,
        )

