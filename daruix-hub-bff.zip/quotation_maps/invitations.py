"""Convites, contas de fornecedores e encerramento de leilões."""
import logging

from django.conf import settings
from django.contrib.auth import get_user_model
from django.contrib.auth.tokens import default_token_generator
from django.core.mail import send_mail
from django.core.validators import validate_email
from django.core.exceptions import ValidationError as DjangoValidationError
from django.db import transaction
from django.db.models import Q
from django.utils import timezone
from django.utils.encoding import force_bytes
from django.utils.http import urlsafe_base64_encode
from rest_framework.exceptions import ValidationError

from accounts.models import Supplier as PortalSupplier
from .models import Supplier, TenderBid, QuotationMap

logger = logging.getLogger(__name__)


def _site_url():
    return getattr(settings, "HUB_PUBLIC_URL", "http://localhost:4300").rstrip("/")


def _api_url():
    return getattr(settings, "HUB_API_PUBLIC_URL", _site_url()).rstrip("/")


def ensure_supplier_account(supplier):
    """Criar somente contas de fornecedor; nunca vincular conta de outro tipo pelo e-mail."""
    if supplier.portal_profile_id:
        profile = supplier.portal_profile
        if not profile.is_active or not profile.user.is_active or profile.user.user_type != "FORNECEDOR":
            raise ValidationError(f"Conta do fornecedor {supplier.name} está inativa ou inválida.")
        return profile.user
    email = supplier.email.strip().lower()
    if not email:
        raise ValidationError(f"Cadastre o e-mail do fornecedor {supplier.name} antes de publicar.")
    try:
        validate_email(email)
    except DjangoValidationError:
        raise ValidationError(f"E-mail inválido para o fornecedor {supplier.name}.")
    User = get_user_model()
    if User.objects.filter(email__iexact=email).exists():
        raise ValidationError(f"O e-mail de {supplier.name} já pertence a uma conta. Vincule o perfil no Cadastro de Fornecedores.")
    # Username estável e sem dados pessoais; senha criada exclusivamente pelo próprio fornecedor.
    user = User(username=f"fornecedor_mc_{supplier.pk}", name=supplier.name[:150],
                email=email, user_type="FORNECEDOR", is_active=True)
    user.set_unusable_password()
    user.save()
    profile = PortalSupplier.objects.create(user=user, legal_name=supplier.name[:180],
                                            trade_name=supplier.trade_name[:150] or None,
                                            document=supplier.document[:20] or None)
    supplier.portal_profile = profile
    supplier.save(update_fields=["portal_profile"])
    return user


def invite_selected(quotation):
    """Reservar as vagas exclusivamente para os fornecedores escolhidos, dentro da transação."""
    ids = [int(q["supplier"]["id"]) for q in quotation.quotes]
    if not 4 <= len(ids) <= 6 or len(ids) != len(set(ids)):
        raise ValidationError("Selecione de 4 a 6 fornecedores distintos antes de publicar.")
    suppliers = Supplier.objects.select_related("portal_profile__user").filter(pk__in=ids, active=True).in_bulk()
    if len(suppliers) != len(ids):
        raise ValidationError("Há fornecedor inativo ou inexistente na cotação.")
    recipients = []
    for supplier_id in ids:
        supplier = suppliers[supplier_id]
        user = ensure_supplier_account(supplier)
        if not user.email:
            raise ValidationError(f"O fornecedor {supplier.name} não possui e-mail válido.")
        TenderBid.objects.get_or_create(quotation=quotation, supplier=supplier)
        recipients.append((supplier.pk, supplier.name, user.pk, user.email))
    return recipients


def send_invitations(quotation_id, recipients):
    quotation = QuotationMap.objects.get(pk=quotation_id)
    tender_url = f"{_site_url()}/hub/obras/leilao-reverso?mapa={quotation_id}"
    for supplier_id, name, user_id, email in recipients:
        try:
            user = get_user_model().objects.get(pk=user_id)
            link = tender_url
            if not user.has_usable_password():
                uid = urlsafe_base64_encode(force_bytes(user.pk))
                token = default_token_generator.make_token(user)
                link = f"{_api_url()}/api/quotation-maps/activate/{uid}/{token}/"
            body = (f"Olá, {name}.\n\nVocê foi convidado a apresentar proposta no Mapa {quotation.code}.\n"
                    f"Seu usuário de acesso é: {user.username}\n"
                    f"Prazo: {timezone.localtime(quotation.tender_deadline):%d/%m/%Y %H:%M}.\n\n"
                    f"Acesse: {link}\n\nEntre com seu usuário e senha ou ative sua senha pelo link."
                    "\nVocê só poderá visualizar seus próprios dados e itens requisitados.\n")
            send_mail(f"Daruix Hub — Convite para cotação {quotation.code}", body,
                      settings.DEFAULT_FROM_EMAIL, [email], fail_silently=False)
        except Exception:
            logger.exception("Falha ao enviar convite do mapa %s ao fornecedor %s", quotation_id, supplier_id)


def close_expired_tender(quotation):
    """Idempotente; chamar sob select_for_update para evitar perda de propostas."""
    if (quotation.tender_opened_at is None or quotation.tender_closed_at is not None
            or quotation.status != QuotationMap.Status.DRAFT
            or quotation.tender_deadline is None or quotation.tender_deadline > timezone.now()):
        return False
    quotes = {int(quote["supplier"]["id"]): quote for quote in quotation.quotes}
    for bid in quotation.tender_bids.filter(submitted_at__isnull=False).exclude(offer__isnull=True).order_by("pk"):
        # O backend já valida ofertas no envio; ao fechar mantemos somente as propostas recebidas.
        quotes[bid.supplier_id] = bid.offer
    quotation.quotes = list(quotes.values())
    quotation.tender_closed_at = timezone.now()
    quotation.version += 1
    quotation.save(update_fields=["quotes", "tender_closed_at", "version"])
    return True


def close_expired_tenders(ids=None):
    filters = Q(tender_opened_at__isnull=False, tender_closed_at__isnull=True,
                tender_deadline__lte=timezone.now(), status=QuotationMap.Status.DRAFT)
    if ids is not None:
        filters &= Q(pk__in=ids)
    total = 0
    # Locks independentes: um mapa com erro não impede os demais.
    for pk in QuotationMap.objects.filter(filters).values_list("pk", flat=True).iterator():
        with transaction.atomic():
            quotation = QuotationMap.objects.select_for_update().get(pk=pk)
            total += int(close_expired_tender(quotation))
    return total
