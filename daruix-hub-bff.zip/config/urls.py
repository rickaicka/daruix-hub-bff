from django.urls import include, path
from django.contrib import admin
from django.urls import include, path
from drf_spectacular.views import (
    SpectacularAPIView,
    SpectacularRedocView,
    SpectacularSwaggerView,
)

urlpatterns = [
    path("api/quotation-maps/", include("quotation_maps.urls")),
    path("api/material-requisitions/", include("material_requisitions.urls")),
    path("admin/", admin.site.urls),
    path("api/", include("accounts.urls")),
    path("api/commercial/", include("commercial.urls")),
    path(
        "api/memorando-remessas/",
        include("memorando_remessas.urls"),
    ),
    path("api/budgeting/", include("budgeting.urls")),
    path(
        "api/schema/",
        SpectacularAPIView.as_view(),
        name="schema",
    ),
    path(
        "api/docs/",
        SpectacularSwaggerView.as_view(url_name="schema"),
        name="swagger-ui",
    ),
    path(
        "api/redoc/",
        SpectacularRedocView.as_view(url_name="schema"),
        name="redoc",
    ),
]
